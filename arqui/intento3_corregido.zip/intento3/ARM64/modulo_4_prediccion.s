// ============================================================
// modulo_4_prediccion.s
// Modulo 4: Prediccion Lineal Simple
// Proyecto: Invernadero Inteligente IoT - ACYE1
//
// Lee 30 valores de la columna seleccionada desde el dashboard
// (guardada por Python en seleccion.txt) y calcula una
// prediccion simple basada en la tendencia promedio.
//
// Formulas:
//   DIF             = X_final - X_inicial
//   PROMEDIO_CAMBIO = DIF / (N - 1)
//   PREDICCION      = X_final + PROMEDIO_CAMBIO
//
// Donde N = 30 (29 intervalos entre 30 datos)
//
// Para leer el CSV uso leer_datos de utils.s
// Para saber que columna usar uso leer_columna_seleccion de utils.s
// Para convertir numeros a texto uso int_a_ascii de utils.s
// ============================================================

.extern leer_datos
.extern int_a_ascii
.extern leer_columna_seleccion
.extern datos

.section .data

nombre_salida:
    .asciz "resultado_prediccion.txt"

linea_module:
    .asciz "MODULE=PREDICTION\n"
linea_module_len = . - linea_module

label_inicial: .asciz "INITIAL_VALUE="
label_final:   .asciz "FINAL_VALUE="
label_diff:    .asciz "TOTAL_DIFF="
label_avg:     .asciz "AVG_CHANGE="
label_next:    .asciz "NEXT_VALUE="

.section .bss

.comm buffer_salida, 512, 8

.comm buf_inicial, 32, 8
.comm buf_final,   32, 8
.comm buf_diff,    32, 8
.comm buf_avg,     32, 8
.comm buf_next,    32, 8

.section .text
.global _start

_start:
    // 1. Leer la columna seleccionada desde el dashboard
    //    (por defecto 1=TEMP si no existe seleccion.txt)
    bl  leer_columna_seleccion
    bl  leer_datos          // datos[] queda con los 30 valores

    // 2. Extraer valor inicial (fila 1) y valor final (fila 30)
    adr x19, datos
    ldr x20, [x19, #0]      // x20 = valor inicial = datos[0]
    ldr x21, [x19, #232]    // x21 = valor final   = datos[29] (29*8=232)

    // 3. Calculos
    sub x22, x21, x20       // x22 = diferencia total = final - inicial
    mov x9,  #29            // 30 datos -> 29 intervalos
    sdiv x23, x22, x9       // x23 = promedio de cambio = diff / 29
    add x24, x21, x23       // x24 = prediccion = final + promedio_cambio

    // 4. Armar el texto de salida en buffer_salida
    // x10 va marcando hasta donde llevamos escrito
    mov x10, #0

    adr x0, linea_module
    bl .copiar_cadena

    // INITIAL_VALUE=
    adr x0, label_inicial
    bl .copiar_cadena
    mov x0, x20
    adr x1, buf_inicial
    bl .formatear_numero
    adr x0, buf_inicial
    bl .copiar_cadena
    bl .copiar_newline

    // FINAL_VALUE=
    adr x0, label_final
    bl .copiar_cadena
    mov x0, x21
    adr x1, buf_final
    bl .formatear_numero
    adr x0, buf_final
    bl .copiar_cadena
    bl .copiar_newline

    // TOTAL_DIFF=
    adr x0, label_diff
    bl .copiar_cadena
    mov x0, x22
    adr x1, buf_diff
    bl .formatear_numero
    adr x0, buf_diff
    bl .copiar_cadena
    bl .copiar_newline

    // AVG_CHANGE=
    adr x0, label_avg
    bl .copiar_cadena
    mov x0, x23
    adr x1, buf_avg
    bl .formatear_numero
    adr x0, buf_avg
    bl .copiar_cadena
    bl .copiar_newline

    // NEXT_VALUE=
    adr x0, label_next
    bl .copiar_cadena
    mov x0, x24
    adr x1, buf_next
    bl .formatear_numero
    adr x0, buf_next
    bl .copiar_cadena
    bl .copiar_newline

    // 5. Crear/sobreescribir resultado_prediccion.txt
    mov x8, #56             // syscall openat
    mov x0, #-100           // AT_FDCWD
    adr x1, nombre_salida
    mov x2, #577            // O_WRONLY|O_CREAT|O_TRUNC
    mov x3, #0644
    svc #0
    mov x11, x0             // descriptor de salida

    // escribir el buffer al archivo
    mov x8, #64
    mov x0, x11
    adr x1, buffer_salida
    mov x2, x10
    svc #0

    // cerrar archivo
    mov x8, #57
    mov x0, x11
    svc #0

    // tambien mostrar en pantalla
    mov x8, #64
    mov x0, #1
    adr x1, buffer_salida
    mov x2, x10
    svc #0

    // salir
    mov x8, #93
    mov x0, #0
    svc #0


// ============================================================
// Funciones internas. Todas usan x10 como posicion actual
// dentro de buffer_salida y la van incrementando.
// ============================================================

// copia la cadena apuntada por x0 (terminada en \0) al buffer_salida
.copiar_cadena:
    stp x29, x30, [sp, #-16]!
    mov x1, x0
    adr x0, buffer_salida
.lp_cad4:
    ldrb w2, [x1]
    cmp w2, #0
    beq .fin_cad4
    strb w2, [x0, x10]
    add x10, x10, #1
    add x1, x1, #1
    b .lp_cad4
.fin_cad4:
    ldp x29, x30, [sp], #16
    ret

.copiar_newline:
    stp x29, x30, [sp, #-16]!
    adr x0, buffer_salida
    mov w2, #10
    strb w2, [x0, x10]
    add x10, x10, #1
    ldp x29, x30, [sp], #16
    ret

// ------------------------------------------------------------
// formatear_numero
// x0 = numero (puede ser negativo), x1 = buffer destino
// Si es negativo escribe '-' y convierte el valor absoluto.
// ------------------------------------------------------------
.formatear_numero:
    stp x29, x30, [sp, #-16]!
    mov x29, sp

    cmp x0, #0
    bge .fn_positivo

    // escribir '-' en el buffer destino y avanzar
    mov w2, #45             // '-'
    strb w2, [x1]
    add x1, x1, #1
    neg x0, x0

.fn_positivo:
    bl int_a_ascii

    ldp x29, x30, [sp], #16
    ret

/*  Para probar:
    make modulo_4_prediccion
    qemu-aarch64 ./modulo_4_prediccion
    cat resultado_prediccion.txt
*/
